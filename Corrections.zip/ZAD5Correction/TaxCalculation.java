package ZAD5Correction;

public interface TaxCalculation {
    double CalculatePriceWithTax(double price);
}
