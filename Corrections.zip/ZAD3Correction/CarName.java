package ZAD3Correction;

public interface CarName {
    void getCarName();
}
