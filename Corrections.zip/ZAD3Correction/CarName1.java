package ZAD3Correction;

public class CarName1 implements CarName{
    @Override
    public void getCarName() {
        System.out.println("Audi");
    }
}
