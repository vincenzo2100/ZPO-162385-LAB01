package ZAD3Correction;

public class CarName2 implements CarName{
    @Override
    public void getCarName() {
        System.out.println("Mercedes");
    }
}
