package ZAD3Correction;

public interface CarSpeed {
    int getMaxSpeed();
}
