package ZAD3Correction;

public class CarSpeed2 implements CarSpeed{
    @Override
    public int getMaxSpeed() {
        return 200;
    }
}
