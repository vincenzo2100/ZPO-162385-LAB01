package ZAD3Correction;

public class CarSpeed1 implements CarSpeed{
    @Override
    public int getMaxSpeed() {
        return 160;
    }
}
